install by drag and dropping data file to your Fallout New Vegas Directory

The Outfit is on the stretcher in Doc Mitchell's office as soon as you get up from the bed